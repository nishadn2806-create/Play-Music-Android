# Play Music source audit — next steps

This package is based on the uploaded Phase 17 source ZIP.

## Change made
- Corrected the malformed `buildConfigField` string quoting for `JAMENDO_CLIENT_ID` in `app/build.gradle.kts`.

## Not yet verified
- This source has not been compiled with Gradle.
- No APK/AAB is included.
- Phase 18, Phase 19 source integration, and Phase 20 release tasks are not fully present in this ZIP; the uploaded Phase 20 file is a checklist pack.
- Online playback/download behavior, signing, and device testing are not verified.

## Build next
1. Open this folder in Android Studio.
2. Set `jamendoClientId` in local Gradle properties if online Jamendo search is intended. Do not add private secrets to source control.
3. Sync Gradle and run a debug build.
4. Fix any compiler/dependency errors shown by Android Studio.
5. Install the debug build and test local playback before preparing a signed release APK.
