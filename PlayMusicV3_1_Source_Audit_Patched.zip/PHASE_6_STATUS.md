# V3.1 Phase 6 Status

Implemented:
- Play online track
- Add online track to Media3 queue
- Metadata for notification/lock-screen
- Background playback remains through MediaSessionService

Not implemented:
- Jamendo OAuth2 account connection
- Provider-side private favorites
- Provider-side playlists
- Permanent downloads

Next:
- Phase 7: Online Favorites & Playlists (local-first first, OAuth2 optional)
- Then full hybrid QA.
