# Play Music V3.1 — Phase 17

Offline-first Android music player with optional online music architecture.

## Phase 17
Library browsing is expanded into dedicated **Albums**, **Artists**, and **Folders** tabs using the device MediaStore library.

### Included
- Jetpack Compose UI
- Media3 playback + background service
- Offline local music library
- Optional Jamendo online architecture
- Downloads / hybrid library / unified queue foundations
- Now Playing + mini-player foundations
- Albums / Artists / Folders browser
- Violet/Lavender headphones branding

### Build
- compileSdk 36
- targetSdk 36
- minSdk 26
- versionCode 41
- versionName 3.11.0

This is a source package. No signed APK/AAB is included.
