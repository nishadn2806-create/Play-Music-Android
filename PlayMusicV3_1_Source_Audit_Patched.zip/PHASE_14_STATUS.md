# Play Music — V3.8 Phase 14: Unified Queue + Now Playing

Implemented:
- One Media3 playlist model for local, online and downloaded tracks.
- Add, add-next, remove, move and clear queue helpers.
- Unified MediaItem builder with title/artist/album/artwork metadata.
- Now Playing state model.
- Now Playing Compose screen with:
  - title/artist/album
  - progress
  - play/pause
  - previous/next
  - queue position
- The design uses the existing Media3 Player/MediaController architecture, so the same queue can continue in background playback.

Architecture note:
- Media3 Player manages a playlist/queue and supports dynamic add/remove/move operations.
- When the Player lives in MediaSessionService, a MediaController can control that same player from the Activity/UI.
- The components in this phase are standalone integration pieces; the existing MainActivity navigation should wire the actual MediaController instance into them.

Build note:
- Source ZIP only; no signed APK/AAB was built in this environment.
