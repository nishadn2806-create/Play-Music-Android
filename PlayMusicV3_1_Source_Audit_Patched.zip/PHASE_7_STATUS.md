# V3.1 Phase 7

Implemented:
- Local-first online favorites
- Local online playlists
- Playlist membership storage
- Offline-safe persistence

Deferred:
- Jamendo OAuth2 login
- Jamendo provider-side favorite synchronization
- Provider-side playlist creation/editing

Reason:
Jamendo documents that write methods require OAuth2 and a Read & Write
application plan. The app should not require an online account merely to keep
local favorites/playlists.
