# Play Music — V3.4 Phase 10: Offline Downloads

Implemented:
- Media3 DownloadService for background downloads.
- Persistent DownloadManager + DownloadIndex.
- Dedicated non-evicting download cache under app files.
- Add/remove/pause/resume download APIs.
- Maximum 2 parallel downloads.
- Foreground download notification.
- Network-download request helper for online progressive audio.
- Download state can be queried from DownloadIndex.
- Existing 150 MB streaming cache remains separate.

Important:
- This phase prepares the real offline-download engine.
- The UI download button/list integration is intentionally the next polish step so the existing Online screen is not destabilized.
- Downloaded media should be played through Media3's cache-aware player path; do not read download files directly.
- Only tracks for which the provider supplies a downloadable/direct audio URI should be offered for download.
- This is source-only; no signed APK/AAB was built in this environment.
