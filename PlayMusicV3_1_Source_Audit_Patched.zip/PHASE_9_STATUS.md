# Play Music — V3.1 Phase 9 / V3.3 Online Caching & Optimization

Implemented:
- Bounded 150 MB on-the-fly online streaming cache.
- LRU eviction so cache storage is automatically reclaimed.
- Cache is stored under the app cache directory.
- CacheDataSource helper with cache-error fallback.
- Cache is explicitly streaming cache, not permanent offline download storage.
- Existing offline library and online queue/favorites/discover architecture remain unchanged.
- Version: 3.3.0 / versionCode 33.

Important:
- The helper is prepared for the Media3 player/service integration. The exact player construction in this source branch should be wired to OnlineMediaCache.dataSourceFactory(...) during final playback integration.
- No permanent downloads are added in this phase.
- Android's documented permanent-download architecture uses DownloadService/DownloadManager/DownloadIndex, which is intentionally reserved for a later download phase.
- Source ZIP only; no signed APK/AAB was built here.
