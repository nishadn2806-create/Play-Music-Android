# Play Music — V3.7 Phase 13: Online Actions Integration

Implemented:
- Shared online track action component.
- Queue action.
- Local-first online Favorite toggle.
- Download action.
- Download action is shown only when the provider reports `audiodownload_allowed=true`.
- Jamendo track model reads `audiodownload_allowed`.
- Download uses the existing Media3 DownloadService/DownloadManager path.
- Existing Online Library storage remains local-first and does not require OAuth login.

Provider rule:
- Jamendo explicitly says artists can disable downloads and applications must check `audiodownload_allowed`; the download file endpoint can return 404 when downloads are not allowed.
- Therefore Play Music does not expose Download for disallowed tracks.

Build note:
- Source ZIP only; no signed APK/AAB was built in this environment.
