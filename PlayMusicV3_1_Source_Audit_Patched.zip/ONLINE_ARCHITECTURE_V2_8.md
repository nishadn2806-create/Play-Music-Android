# Play Music V2.8 — Online Music Architecture

Play Music remains offline-first. V2.8 adds the foundation for a legal online catalogue/provider without changing the local library or Media3 playback core.

## Offline path
MediaStore -> local library -> Media3/MediaSession

## Online path
Online UI -> provider repository -> OnlineMusicProvider -> selected official API/SDK

## Added in V2.8
- Online Music navigation screen
- Network availability detection
- Provider-neutral track/album/artist/playable-item models
- Provider adapter interface
- INTERNET permission
- Offline fallback remains available when internet is unavailable

## Rules
- No scraping or unofficial audio extraction.
- No provider credentials in source.
- Online data must not replace the local MediaStore library.
- Provider-specific authentication, licensing and playback rules stay behind an adapter.

## V2.9
Select one legal provider and implement its official API/SDK, authentication, search and provider-supported playback.


## V3.1 RC status note
The provider-neutral online architecture remains a foundation only. A real
online provider and streaming implementation must be completed and tested
before calling the app a production hybrid release.
